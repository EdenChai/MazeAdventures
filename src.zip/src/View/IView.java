package View;

import algorithms.mazeGenerators.Maze;

public interface IView
{
    void displayMaze(Maze maze);
}
